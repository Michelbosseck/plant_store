package com.shashank.plantshopappui.theme

import androidx.compose.ui.graphics.Color

val white = Color(0xffffffff)
val black = Color(0xff000000)
val paleWhite = Color(0xfff3f7f9)
val paleBlack = Color(0xff222325)
val green = Color(98, 192, 80)
val eveningGlory = Color(56, 72, 97)
val cottonBall = Color(241, 244, 253)
val annapolosBlue = Color(54, 73, 100)
val anon = Color(187, 191, 199)
val veiledSpotlight= Color(208, 211, 215)
val lightSilver = Color(209,215,224)
val grey= Color(131,131,141)
